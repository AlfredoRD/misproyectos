﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void ejerccio5()
        {

        }
        static void Verproducto()
        {
            Producto bebida = new Producto("cafe", "con leche");
            bebida.Nombre = "cafe";
            bebida.Descripcion = "leche, azucuar";
            Producto pan = new Producto("hamburgueza", "sin cebolla");
            pan.Nombre = "hanburgueza";
            pan.Descripcion = "pan, queso, cebolla";
            Console.WriteLine($"producto2;\n { bebida}");

            Console.WriteLine($"producto3; \n { pan}");
            Console.ReadKey();

        }
        private static void ejercicio3()
        {
            Random aleatorio = new Random();

            int numsuerte = aleatorio.Next(1, 100), contador = 0, numero ;
            do
            {
                Console.WriteLine("numero aleatorio del 1 al 100, tienes 6 opotunidades");
                numero = int.Parse(Console.ReadLine());
                contador++;
               
                Console.Clear();
                if (contador < 7)

                    Console.WriteLine("sigue intentandolo vas por el intento " + contador);

                else if (contador < 7)
                {
                    Console.WriteLine("has perdio :(");
                    Console.ReadKey();
                }

            } while (contador < 7);
        }

        private static string HolaEstudiantes()

            {
                string nombre = "Alfredo";
                return nombre;
            }

        private static void Saludo()
            {
                Console.WriteLine("hola, Estiduante " + HolaEstudiantes() + " Bienvenido a programacion 1");
            Console.ReadKey();
            }

        private static void Ejecicio2()
        {
            int contador;
            Console.Clear();
            Console.WriteLine("Escriba 1 para ver el contador");
            contador = int.Parse(Console.ReadLine());


            for (int cuenta = 0; cuenta < 51; cuenta++)
            {
                if (contador == 1) ;
                Console.WriteLine(cuenta);
            }

            Console.ReadKey();
        }

        private static void Ejercio3() {
            
           
        }

        private static void Main(string[] args)
        {


            string opcion;

            
            Vehiculo Honda = new Vehiculo("Honda", "Insight", 2005, "azul");
            Honda.Color = "azul";
            Honda.Marca = "honda";
            Honda.Modelo = "insight";
            Honda.Ano = 2005;
            Honda.Estado = "off";



            do
            {
                
                Console.Clear();
                Console.WriteLine("elija el numero de ejercicio que quieres ver {1} al {5}, {6} para salir");
                opcion = Console.ReadLine();
                switch (opcion)
                {
                    case "1":
                        Saludo();
                        break;
                    case "2":
                        Ejecicio2();
                        break;
                    case "3": ejercicio3();
                            break;
                    case "4":
                        
                        {
                            Console.Clear();
                            Console.WriteLine("El carro esta apagado?, escriba si para manejar no para continuar ");
                            Honda.Estado = Console.ReadLine();
                            if (Honda.Estado == "no")
                            {
                                Console.Clear();
                                Honda.Estado = "Apagado";
                                Console.WriteLine(Honda);
                                Console.ReadKey();

                            }


                            else if (Honda.Estado == "si")
                            {


                                Honda.Estado = "Encendido";
                                Console.WriteLine("Estas manejando brum brum");
                                Console.WriteLine(Honda);
                                Console.ReadKey();

                            }
                        }
                        break;
                    case "5":
                        Verproducto();
                        break;
                    

                }

            } while (opcion != "6");
        
          
          






        }

    }
}
