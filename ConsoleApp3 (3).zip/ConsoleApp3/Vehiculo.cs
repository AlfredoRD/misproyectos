﻿namespace ConsoleApp3
{
    internal class Vehiculo
    {

        private string _Marca;
        private string _Modelo;
        private int _Ano;
        private string _Color;
        public string _Estado;

   
        public Vehiculo(string v1, string v2, int v3, string v4)
        {
            this.Marca = Marca;
            this.Modelo = Modelo;
            this.Ano = Ano;
            this.Color = Color;
            this.Estado = Estado;
        }

        public string Marca { get => _Marca; set => _Marca = value; }
        public string Modelo { get => _Modelo; set => _Modelo = value; }
        public int Ano { get => _Ano; set => _Ano = value; }
        public string Color { get => _Color; set => _Color = value; }
        public string Estado { get => _Estado; set => _Estado = value; }

        public override string ToString()
        {
            return $"Estado: {Estado}\n Marca: {Marca}\n Modelo: {Modelo}\n Año: {Ano}\n Color:{Color}";

        }

        

    }
}

